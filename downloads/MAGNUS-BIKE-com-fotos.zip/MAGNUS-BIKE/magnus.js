const WHATSAPP = 'https://api.whatsapp.com/send?phone=5537999346858&text=Ol%C3%A1!%20Vim%20pelo%20Instagram%2C%20gostaria%20de%20mais%20informa%C3%A7%C3%B5es';
const INSTAGRAM = 'https://www.instagram.com/magnusbikelp/';
import { mountPhotoGallery } from './magnus-gallery.js';
const hero = document.querySelector('.hero');
const dialog = document.querySelector('.info-dialog');
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const status = document.querySelector('#asset-status');
const view = document.querySelector('#model-view');
const video = document.querySelector('video');
let controller, focused = false, disposed = false;
for (const link of document.querySelectorAll('[data-whatsapp], [data-instagram]')) {
  link.href = link.hasAttribute('data-whatsapp') ? WHATSAPP : INSTAGRAM;
  link.target = '_blank'; link.rel = 'noopener noreferrer';
}
function showInfo(title, description) {
  dialog.querySelector('h2').textContent = title;
  dialog.querySelector('.dialog-copy').textContent = description;
  dialog.showModal();
}
function setFocused(value) {
  focused = value;
  if(value) video.pause(); else motionChanged();
  hero.classList.toggle('is-focused', value);
  document.querySelector('.focus-ui').hidden = !value;
  document.querySelector('.nav').classList.remove('menu-open');
  document.querySelector('.menu-toggle').setAttribute('aria-expanded', 'false');
  controller?.setFocused(value);
  if (value) document.querySelector('[data-home].back').focus({preventScroll:true});
}
document.querySelectorAll('[data-explore]').forEach(button => button.addEventListener('click', () => {setFocused(true); loadModel();}));
document.querySelectorAll('[data-home]').forEach(button => button.addEventListener('click', () => {setFocused(false); document.querySelector('[data-explore]').focus({preventScroll:true});}));
document.querySelector('.brand').addEventListener('click', () => setFocused(false));
document.querySelector('[data-about]').addEventListener('click', () => showInfo('Uma nova forma de se mover.', 'A MAGNUS BIKE é especializada em scooters e mobilidade elétrica. Converse diretamente com a nossa equipe para conhecer os modelos e encontrar uma opção para o seu dia a dia.'));
document.querySelector('.dialog-close').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', e => {if(e.target === dialog) {const b=dialog.getBoundingClientRect(); if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom) dialog.close();}});
document.querySelector('.menu-toggle').addEventListener('click', e => {const open=hero.querySelector('.nav').classList.toggle('menu-open'); e.currentTarget.setAttribute('aria-expanded', String(open));});
document.addEventListener('keydown', e => {if(e.key === 'Escape' && !dialog.open) setFocused(false);});
let config, loading;
const configuration = fetch('/magnus/config.json').then(r => {if(!r.ok) throw Error('config');return r.json();}).catch(() => ({}));
configuration.then(value => {
  config=value;
  if (!config.modelUrl) mountPhotoGallery(config.photos);
  if(config.videoUrl && !reduced.matches && !navigator.connection?.saveData) {
    video.src=config.videoUrl; video.autoplay=true; video.preload='auto';
    video.addEventListener('error',()=>{video.hidden=true;});
    video.play().catch(()=>{video.hidden=true;});
  }
});
function motionChanged() {if(reduced.matches) video.pause(); else if(video.src&&!document.hidden&&!focused) video.play().catch(()=>{});}
reduced.addEventListener('change', motionChanged);
async function loadModel() {
  if(controller || loading || disposed) return;
  loading=true;
  config=await configuration;
  if(!config.modelUrl) {loading=false;return;}
  status.textContent='CARREGANDO VISUALIZAÇÃO 3D…';
  try {
    const {createViewer}=await import('./magnus-viewer.js');
    if(disposed) return;
    controller=await createViewer(view, config, {reduced, showInfo});
    if(disposed) {controller.dispose();return;}
    document.querySelector('.scooter-fallback').hidden=true;
    document.querySelector('.model-tools').hidden=false;
    status.textContent=config.modelLabel || 'Scooter elétrica';
    controller.setFocused(focused);
  } catch(error) {
    view.hidden=true;
    status.textContent='Visualização 3D indisponível · consulte os modelos na loja';
    console.warn('Não foi possível carregar o modelo de scooter.', error.message);
  } finally {loading=false;}
}
document.querySelector('[data-reset]').addEventListener('click',()=>controller?.reset());
document.querySelector('[data-rotate]').addEventListener('click',()=>controller?.rotate());
document.querySelectorAll('[data-zoom]').forEach(b=>b.addEventListener('click',()=>controller?.zoom(b.dataset.zoom==='in' ? .85 : 1.18)));
document.querySelector('[data-details]').addEventListener('click',()=>showInfo(config?.modelLabel||'Scooter elétrica','Explore os pontos de interesse no modelo. Para especificações e opções disponíveis, consulte a equipe MAGNUS BIKE.'));
document.addEventListener('visibilitychange',()=>{if(document.hidden)video.pause();else motionChanged();});
window.addEventListener('pagehide',()=>{disposed=true;controller?.dispose();video.pause();reduced.removeEventListener('change',motionChanged);},{once:true});
