// Photographs remain photographs: no simulated 3D or invented product details.
export async function mountPhotoGallery(photos) {
  if (!Array.isArray(photos) || !photos.length) return;
  const loaded = await Promise.all(photos.map(async (photo) => {
    if (!photo || typeof photo.src !== 'string' || typeof photo.alt !== 'string') return null;
    const image = new Image();
    image.src = photo.src;
    try { await image.decode(); return photo; } catch { return null; }
  }));
  const available = loaded.filter(Boolean);
  if (!available.length) return;
  const hero = document.querySelector('.hero');
  const image = document.querySelector('.scooter-fallback');
  const status = document.querySelector('#asset-status');
  const gallery = document.createElement('div');
  gallery.className = 'photo-selector';
  gallery.setAttribute('role', 'group');
  gallery.setAttribute('aria-label', 'Escolher foto da scooter');
  const count = document.querySelector('.view-label > span');
  const buttons = [];
  function select(index) {
    const photo = available[index];
    image.src = photo.src;
    image.alt = photo.alt;
    status.textContent = photo.label || `Foto ${index + 1}`;
    const caption = document.createElement('small');
    caption.textContent = 'Fotografia · consulte os detalhes com a MAGNUS';
    status.append(caption);
    count.textContent = `${String(index + 1).padStart(2, '0')} / ${String(available.length).padStart(2, '0')}`;
    buttons.forEach((button, i) => button.setAttribute('aria-pressed', String(i === index)));
  }
  available.forEach((photo, index) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.setAttribute('aria-label', `Ver ${photo.label || `foto ${index + 1}`}`);
    const thumbnail = document.createElement('img');
    thumbnail.src = photo.src;
    thumbnail.alt = '';
    button.append(thumbnail);
    button.addEventListener('click', () => select(index));
    buttons.push(button);
    gallery.append(button);
  });
  document.querySelector('.stage').append(gallery);
  hero.classList.add('has-photos');
  select(0);
}
