# CMC Enxovais — projeto completo

Pacote de exportação do site CMC Enxovais. Inclui o código-fonte, páginas de autenticação e administração, API Express e as imagens realmente usadas no site. As imagens antes servidas pelo armazenamento Manus foram incluídas em `public/assets/` e referenciadas localmente nesta cópia. O build de produção é gerado localmente com `pnpm run build`.

## Requisitos

- Node.js 22
- pnpm 10.16.1 (via Corepack)
- Banco de dados MySQL compatível

## Instalação e execução

1. Instale as dependências: `corepack enable` e `pnpm install --frozen-lockfile`.
2. Copie `.env.example` para `.env` e preencha os valores reais. O arquivo `.env` não deve ser publicado nem enviado a terceiros.
3. Carregue as variáveis de ambiente no shell e inicie: `set -a; . ./.env; set +a; pnpm run dev`.
4. Abra `http://localhost:3000`.

O servidor cria as tabelas necessárias no MySQL ao iniciar. `DATABASE_URL` é obrigatório. Para confirmação de e-mail e recuperação de senha, configure também `RESEND_API_KEY` e `RESEND_FROM_EMAIL` com um remetente verificado no Resend. Defina `PUBLIC_ORIGIN` para a URL pública correta ao hospedar. `ADMIN_EMAIL` usa `aurumnorthgroup@gmail.com` como padrão.

Para compilar: `pnpm run build`. Para iniciar em produção: `set -a; . ./.env; set +a; pnpm start`. O Dockerfile da raiz também contém a receita de imagem de produção.

## Arquivos principais

- `index.html`, `styles.css`, `main.js`: página inicial e interações.
- `auth.html`, `auth.css`, `auth.js`: login e cadastro.
- `admin.html`, `admin.css`, `admin.js`: painel administrativo.
- `server/index.js`: API, autenticação, leads e integração de e-mail.
- `assets/` e `public/assets/`: imagens usadas pelo site.
- `dist/`: diretório de saída gerado pelo comando de build.

O Google Sites não executa o backend Express nem o banco de dados deste projeto. Para usar o site completo nesse serviço, é necessário hospedar o projeto com Node.js/MySQL e incorporar a URL pública por iframe; importar somente `index.html` não habilita login, formulários ou painel administrativo.

## Apresentação e vitrine de fotos

A abertura voltou à foto frontal da cama e da mulher, com entrada suave e movimento discreto. Após o carregamento da foto, a página aguarda cinco segundos visíveis e desce para a vitrine. Rolar, tocar, usar o teclado ou clicar em um controle cancela essa descida. Entradas por âncora e páginas já roladas preservam a posição do visitante.

A vitrine alterna a cada cinco segundos entre as quatro fotos reais em `public/assets/products/`: taça, chaleira, air fryer e almofadas. Há seleção direta, anterior, próximo e pausa da apresentação completa. A vitrine usa o produto inteiro em tamanho grande, título preto em letras maiúsculas condensadas ao fundo e transição de aproximadamente um segundo com deslocamento suave, rotação leve no plano e sobreposição das fotos. A apresentação inicial mantém as fotos inteiras, sem recortes ou criação de lados não fotografados. O temporizador só funciona com a vitrine visível e a aba ativa. A preferência por movimento reduzido desliga as animações e inicia a troca automática pausada. Os módulos e a dependência de Three.js foram removidos.

- `intro-presentation.js`: apresentação inicial, pausa e descida automática.
- `showcase.js`: carrossel de produtos e links de consulta.
- `product-motion.js` e `product-motion.css`: transições das fotografias inteiras e originais.
- `presentation.css` e `showcase.css`: apresentação responsiva das fotos.

O backend, os formulários, a autenticação, as páginas administrativas e o conteúdo comercial após a vitrine permanecem preservados. A vitrine não altera preços nem cria itens comerciais.

## Validação da interface

Para a interface sem banco: `pnpm exec vite --host 0.0.0.0`. Esse modo não fornece a API Express. Para o site completo, use Node/MySQL e as variáveis descritas no início deste documento.

`pnpm run build` compila as páginas. Instale o navegador com `pnpm exec playwright install chromium` e execute `pnpm test`. Em máquinas com Chromium instalado, use `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH=/usr/bin/chromium pnpm test`.

Os testes verificam o intervalo da abertura, a descida, a troca automática, a pausa, as quatro fotos, a navegação manual e o layout móvel com movimento reduzido. A consulta inicial de sessão é isolada como usuário deslogado; MySQL e e-mail exigem as credenciais do ambiente e não são cobertos por esses testes.

A fonte Anton é distribuída localmente com sua licença OFL. O botão “Modo 3D · foto em perspectiva” permite inclinar a fotografia com arraste ou setas, com ângulo limitado; não é um modelo volumétrico nem uma vista de 360 graus. A troca automática fica suspensa durante essa exploração. O controle de gavetas da air fryer só aparece nesse produto e inicia uma montagem ilustrativa usando os pixels da própria foto, sem gerar um produto substituto. “Abrir gavetas” retorna à posição fotografada. As imagens originais não são alteradas.

A apresentação inspirada na referência de vídeo posiciona nome e texto à esquerda e a foto completa em destaque à direita, com layout empilhado no celular. A troca combina entrada diagonal suave, saída da foto anterior, entrada sequenciada dos textos e revelação circular da nova cor de fundo. Uma flutuação discreta só funciona com a vitrine visível, aba ativa e apresentação em execução; o modo em perspectiva e a preferência de movimento reduzido desativam esse movimento. Os produtos mantêm os arquivos originais.

## MAGNUS BIKE

A página inicial agora contém a experiência MAGNUS BIKE, em uma única tela. O site CMC anterior permanece em `/cmc.html`; autenticação, administração e APIs existentes continuam disponíveis. `pnpm run build` inclui as duas páginas. Após mudar os fontes, refaça o build para atualizar a página servida pelo Express (`pnpm run dev`); para recarga automática da interface, use `pnpm exec vite --host 0.0.0.0`.

- `magnus.css` e `magnus.js`: composição responsiva e interações da página inicial.
- `magnus-viewer.js`: Three.js carregado somente ao explorar um modelo configurado. Oferece OrbitControls, zoom limitado, reinício, teclado, iluminação, sombras e hotspots associados a nós reais do GLTF.
- `public/magnus/config.json`: caminhos locais ou URLs autorizadas de mídia. `modelUrl` aceita GLB/GLTF e `videoUrl` aceita vídeo de scooter. Para GLTF com arquivos externos, preserve seus caminhos relativos. Arquivos externos exigem CORS no servidor de origem. Prefira GLB otimizado, com texturas compactas e sem extensões de compressão que exijam decoders adicionais.
- As seis fotografias enviadas no arquivo `foto.rar` estão em `public/magnus/photos/`, preservadas sem edição e selecionáveis por miniaturas. Não há vídeo, variantes de cor, preços ou especificações inventadas. Controles 3D só aparecem depois de um carregamento real bem-sucedido.

Exemplo de configuração **somente após obter e validar os arquivos e informações da loja**:

```json
{
  "modelUrl": "/magnus/scooter.glb",
  "videoUrl": "/magnus/urban-scooter.mp4",
  "modelLabel": "Nome confirmado pela loja",
  "hotspots": [
    {"node": "NomeExatoDoNoGLTF", "name": "Componente confirmado", "description": "Descrição verificada pela loja."}
  ]
}
```

Hotspots sem nó correspondente são omitidos. Rotação: arrastar ou setas com o visualizador focado. Zoom: pinça, roda do mouse e botões +/−. Home restaura a câmera. Escape fecha os detalhes ou retorna à apresentação. Preferência por movimento reduzido impede reprodução automática do vídeo e desativa transições; falha de WebGL ou de mídia mantém o fallback. Os links de WhatsApp e Instagram usam os endereços oficiais do briefing.

`PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH=/usr/bin/chromium pnpm test` executa a regressão CMC e as verificações MAGNUS de navegação, contatos, celular, falha do modelo e carregamento/controles de um GLTF sintético de teste (sem apresentá-lo como produto). E-mails e mídia oficial não são validados por esses testes.

Para fotos reais, adicione os arquivos originais em `public/magnus/` e preencha `photos` em `public/magnus/config.json` com objetos `{ "src": "/magnus/arquivo.jpg", "alt": "Descrição visual da foto", "label": "Foto 1" }`. Sem `modelUrl`, as fotos válidas aparecem com seleção por miniaturas dentro do mesmo hero; arquivos ausentes são omitidos. Os originais e seus fundos são preservados. A lista já contém as seis fotos do arquivo enviado pelo usuário.
