import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';

export async function createViewer(host, config, {reduced, showInfo}) {
  host.hidden=false;
  let renderer, controls, observer, environment, model, frame, stopped=false;
  const markers=[];
  const scene=new THREE.Scene();
  const camera=new THREE.PerspectiveCamera(35,1,.01,100);
  function dispose(){
    stopped=true;cancelAnimationFrame(frame);observer?.disconnect();
    host.removeEventListener('keydown',keyboard);
    document.removeEventListener('visibilitychange',visibility);
    renderer?.domElement.removeEventListener('webglcontextlost',contextLost);
    controls?.dispose();
    scene.traverse(o=>{o.geometry?.dispose(); if(o.material) for(const m of [].concat(o.material)){for(const v of Object.values(m))if(v?.isTexture)v.dispose();m.dispose();}});
    markers.forEach(m=>m.button.remove());environment?.dispose();renderer?.dispose();renderer?.domElement.remove();
  }
  function contextLost(e){e.preventDefault();dispose();host.hidden=true;document.querySelector('.scooter-fallback').hidden=false;document.querySelector('.model-tools').hidden=true;document.querySelector('#asset-status').textContent='Visualização indisponível · visual conceitual';}
  function keyboard(e){
    if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','+','-','=','Home'].includes(e.key))return;
    e.preventDefault();const delta=new THREE.Vector3().subVectors(camera.position,controls.target);
    if(e.key==='Home'){reset();return;}
    if(['+','=','-'].includes(e.key)) {zoom(e.key==='-'?1.15:.87);return;}
    const spherical=new THREE.Spherical().setFromVector3(delta);
    spherical.theta+=e.key==='ArrowLeft'?.12:e.key==='ArrowRight'?-.12:0;
    spherical.phi=THREE.MathUtils.clamp(spherical.phi+(e.key==='ArrowUp'?-.1:e.key==='ArrowDown'?.1:0),controls.minPolarAngle,controls.maxPolarAngle);
    camera.position.copy(controls.target).add(new THREE.Vector3().setFromSpherical(spherical));controls.update();
  }
  function reset(){camera.position.set(3,1.6,4);controls.target.set(0,.7,0);controls.update();}
  function zoom(factor){const v=camera.position.clone().sub(controls.target);v.setLength(THREE.MathUtils.clamp(v.length()*factor,controls.minDistance,controls.maxDistance));camera.position.copy(controls.target).add(v);controls.update();}
  function visibility(){if(!document.hidden&&!stopped&&!frame)render();}
  function render(){
    frame=null;if(stopped||document.hidden)return;
    controls.enableDamping=!reduced.matches;controls.update();
    const raycaster=new THREE.Raycaster();
    for(const marker of markers){
      const point=marker.object.getWorldPosition(new THREE.Vector3());
      const distance=camera.position.distanceTo(point);raycaster.set(camera.position,point.clone().sub(camera.position).normalize());
      const hit=raycaster.intersectObject(model,true)[0];const projected=point.clone().project(camera);
      marker.button.hidden=projected.z>1||projected.z< -1||Math.abs(projected.x)>1||Math.abs(projected.y)>1||(hit&&hit.distance<distance-.08);
      marker.button.style.left=`${(projected.x+1)*host.clientWidth/2}px`;marker.button.style.top=`${(-projected.y+1)*host.clientHeight/2}px`;
    }
    renderer.render(scene,camera);frame=requestAnimationFrame(render);
  }
  try {
    renderer=new THREE.WebGLRenderer({alpha:true,antialias:devicePixelRatio<2,powerPreference:'low-power'});
    renderer.setPixelRatio(Math.min(devicePixelRatio,1.75));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;
    renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
    host.append(renderer.domElement);renderer.domElement.addEventListener('webglcontextlost',contextLost);
    const pmrem=new THREE.PMREMGenerator(renderer);const room=new RoomEnvironment();environment=pmrem.fromScene(room,.04);scene.environment=environment.texture;room.dispose();pmrem.dispose();
    scene.add(new THREE.HemisphereLight(0xdcebdd,0x202720,2));
    const light=new THREE.DirectionalLight(0xffffff,4);light.position.set(3,6,4);light.castShadow=true;light.shadow.mapSize.set(1024,1024);scene.add(light);
    const rim=new THREE.DirectionalLight(0xc7ffa1,3);rim.position.set(-4,2,-3);scene.add(rim);
    const floor=new THREE.Mesh(new THREE.PlaneGeometry(20,20),new THREE.ShadowMaterial({opacity:.3}));floor.rotation.x=-Math.PI/2;floor.receiveShadow=true;scene.add(floor);
    const gltf=await new GLTFLoader().loadAsync(config.modelUrl);
    model=gltf.scene;const box=new THREE.Box3().setFromObject(model);const size=box.getSize(new THREE.Vector3());const extent=Math.max(size.x,size.y,size.z);if(!Number.isFinite(extent)||extent<=0)throw Error('Modelo sem geometria válida');
    model.scale.multiplyScalar(2.7/extent);box.setFromObject(model);const center=box.getCenter(new THREE.Vector3());model.position.sub(new THREE.Vector3(center.x,box.min.y,center.z));
    model.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});scene.add(model);
    controls=new OrbitControls(camera,renderer.domElement);controls.enablePan=false;controls.enableDamping=true;controls.dampingFactor=.065;controls.minDistance=2.4;controls.maxDistance=7;controls.minPolarAngle=.35;controls.maxPolarAngle=Math.PI/2-.03;controls.autoRotate=false;reset();
    // Only configured, verified components bound to real GLTF nodes become hotspots.
    for(const item of (config.hotspots||[])) {
      const object=typeof item.node==='string'&&model.getObjectByName(item.node);
      if(!object||!item.name||!item.description)continue;
      const button=document.createElement('button');button.className='hotspot';button.textContent='+';button.setAttribute('aria-label',item.name);button.addEventListener('pointerdown',e=>e.stopPropagation());button.addEventListener('click',()=>showInfo(item.name,item.description));host.append(button);markers.push({object,button});
    }
    observer=new ResizeObserver(()=>{const w=host.clientWidth,h=host.clientHeight;if(!w||!h)return;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h,false);});observer.observe(host);
    host.addEventListener('keydown',keyboard);document.addEventListener('visibilitychange',visibility);render();
    return {dispose,reset,zoom,rotate(){const d=camera.position.clone().sub(controls.target).applyAxisAngle(new THREE.Vector3(0,1,0),Math.PI/6);camera.position.copy(controls.target).add(d);controls.update();},setFocused(value){if(!value)reset();}};
  }catch(error){dispose();throw error;}
}
