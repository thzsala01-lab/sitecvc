import {test, expect} from '@playwright/test';
const whatsapp='https://api.whatsapp.com/send?phone=5537999346858&text=Ol%C3%A1!%20Vim%20pelo%20Instagram%2C%20gostaria%20de%20mais%20informa%C3%A7%C3%B5es';
test('Magnus single hero preserves contact URLs, exploration, details and keyboard dismissal',async({page})=>{
  const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('/');
  await expect(page).toHaveTitle(/MAGNUS BIKE/);
  await expect(page.locator('main')).toHaveCount(1);
  await expect(page.locator('footer,section')).toHaveCount(0);
  await expect(page.locator('h1')).toHaveText('ELECTRIC FREEDOM');
  for(const a of await page.locator('[data-whatsapp]').all()){await expect(a).toHaveAttribute('href',whatsapp);await expect(a).toHaveAttribute('rel','noopener noreferrer');}
  await expect(page.locator('[data-instagram]')).toHaveAttribute('href','https://www.instagram.com/magnusbikelp/');
  await page.locator('.hero-copy [data-explore]').click();
  await expect(page.locator('.hero')).toHaveClass(/is-focused/);
  await expect(page.locator('.model-tools')).toBeHidden();
  await expect(page.locator('.scooter-fallback')).toBeVisible();
  await page.keyboard.press('Escape');await expect(page.locator('.hero')).not.toHaveClass(/is-focused/);
  await page.locator('[data-about]').click();await expect(page.getByRole('dialog')).toBeVisible();
  await page.keyboard.press('Escape');await expect(page.getByRole('dialog')).not.toBeVisible();
  expect(errors).toEqual([]);
});
test('mobile menu and reduced motion stay accessible without horizontal overflow',async({page})=>{
  await page.setViewportSize({width:390,height:844});await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/');
  await page.getByRole('button',{name:'Abrir menu'}).click();await expect(page.locator('.menu-toggle')).toHaveAttribute('aria-expanded','true');
  await page.locator('nav [data-explore]').click();await expect(page.locator('.hero')).toHaveClass(/is-focused/);
  await expect(page.locator('.menu-toggle')).toHaveAttribute('aria-expanded','false');
  await page.locator('.back').click();await expect(page.locator('.hero')).not.toHaveClass(/is-focused/);
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  const bounds=await page.locator('.cta-row').boundingBox();expect(bounds.x+bounds.width).toBeLessThanOrEqual(390);
  expect(await page.locator('video').evaluate(v=>v.paused)).toBe(true);
});
test('missing GLB degrades to honest illustration without enabling unavailable controls',async({page})=>{
  await page.route('**/magnus/config.json',r=>r.fulfill({json:{modelUrl:'/missing-scooter.glb'}}));
  await page.route('**/missing-scooter.glb',r=>r.fulfill({status:404,body:'not found'}));
  await page.goto('/');await page.locator('.hero-copy [data-explore]').click();
  await expect(page.locator('#asset-status')).toContainText('indisponível',{timeout:20000});
  await expect(page.locator('.scooter-fallback')).toBeVisible();await expect(page.locator('.model-tools')).toBeHidden();
});

test('real GLTF loader renders a synthetic test fixture and enables camera controls',async({page})=>{
  // A cube fixture validates the integration; it is never shipped as a scooter asset.
  const {BoxGeometry}=await import('three');
  const geo=new BoxGeometry(1,1,1).toNonIndexed();
  const pos=geo.attributes.position.array, norm=geo.attributes.normal.array;
  const binary=Buffer.concat([Buffer.from(pos.buffer),Buffer.from(norm.buffer)]);
  const fixture={asset:{version:'2.0'},scene:0,scenes:[{nodes:[0]}],nodes:[{name:'Fixture',children:[1,2]},{mesh:0},{name:'Marker',translation:[0,.5,.55]}],meshes:[{primitives:[{attributes:{POSITION:0,NORMAL:1},material:0}]}],materials:[{pbrMetallicRoughness:{baseColorFactor:[.4,.6,.3,1],metallicFactor:.5,roughnessFactor:.4}}],buffers:[{byteLength:binary.length,uri:'data:application/octet-stream;base64,'+binary.toString('base64')}],bufferViews:[{buffer:0,byteOffset:0,byteLength:pos.byteLength},{buffer:0,byteOffset:pos.byteLength,byteLength:norm.byteLength}],accessors:[{bufferView:0,componentType:5126,count:pos.length/3,type:'VEC3',min:[-.5,-.5,-.5],max:[.5,.5,.5]},{bufferView:1,componentType:5126,count:norm.length/3,type:'VEC3'}]};
  await page.route('**/magnus/config.json',r=>r.fulfill({json:{modelUrl:'/test-fixture.gltf',modelLabel:'Fixture de teste',hotspots:[{node:'Marker',name:'Componente de teste',description:'Somente para validar o visualizador.'}]}}));
  await page.route('**/test-fixture.gltf',r=>r.fulfill({json:fixture}));
  await page.goto('/');await page.locator('.hero-copy [data-explore]').click();
  await expect(page.locator('#asset-status')).toHaveText('Fixture de teste',{timeout:30000});
  await expect(page.locator('#model-view canvas')).toBeVisible();
  await expect(page.locator('.scooter-fallback')).toBeHidden();await expect(page.locator('.model-tools')).toBeVisible();
  const canvas=page.locator('#model-view canvas');
  const before=await canvas.screenshot();await page.getByRole('button',{name:'Girar scooter'}).click();
  await expect.poll(async()=>!(await canvas.screenshot()).equals(before)).toBe(true);
  await page.getByRole('button',{name:'Aproximar',exact:true}).click();await page.getByRole('button',{name:'Restaurar câmera'}).click();
  await page.locator('#model-view').focus();await page.keyboard.press('ArrowLeft');
  await page.getByRole('button',{name:'Detalhes do produto'}).click();await expect(page.getByRole('dialog')).toContainText('Fixture de teste');
  await page.keyboard.press('Escape');
  await expect(page.locator('.hotspot')).toHaveCount(1);
  geo.dispose();
});

test('photo selector uses loaded originals and supports switching photos on mobile',async({page})=>{
  await page.setViewportSize({width:390,height:844});
  await page.route('**/magnus/config.json',r=>r.fulfill({json:{photos:[
    {src:'/magnus/scooter.svg?first',alt:'Primeira imagem de teste',label:'Foto 1'},
    {src:'/magnus/scooter.svg?second',alt:'Segunda imagem de teste',label:'Foto 2'},
    {src:'/magnus/missing.jpg',alt:'Arquivo ausente',label:'Não deve aparecer'}
  ]}}));
  await page.route('**/magnus/missing.jpg',r=>r.fulfill({status:404,body:''}));
  await page.goto('/');
  await expect(page.getByRole('group',{name:'Escolher foto da scooter'})).toBeVisible();
  await expect(page.locator('.photo-selector button')).toHaveCount(2);
  await expect(page.locator('.scooter-fallback')).toHaveAttribute('alt','Primeira imagem de teste');
  await page.getByRole('button',{name:'Ver Foto 2',exact:true}).click();
  await expect(page.locator('.scooter-fallback')).toHaveAttribute('src','/magnus/scooter.svg?second');
  await expect(page.getByRole('button',{name:'Ver Foto 2',exact:true})).toHaveAttribute('aria-pressed','true');
  await expect(page.locator('#asset-status')).toContainText('Fotografia');
  await page.locator('.hero-copy [data-explore]').click();
  await expect(page.getByRole('group',{name:'Escolher foto da scooter'})).toBeVisible();
  await expect(page.locator('.model-tools')).toBeHidden();
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
});
